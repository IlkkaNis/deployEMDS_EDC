from flask import Flask, render_template_string, request
import configparser
import os
import requests
import json
import time

app = Flask(__name__)

# --- Load configuration ---
CONFIG_FILE = "consumer-configuration.properties"
connectors = {}
CONSUMER_URL = ""

if os.path.exists(CONFIG_FILE):
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE)

    if "DEFAULT" in config and "CONSUMER_URL" in config["DEFAULT"]:
        CONSUMER_URL = config["DEFAULT"]["CONSUMER_URL"].rstrip("/")

    for section in config.sections():
        connectors[section] = {
            "name": config[section].get("CONNECTOR_NAME", "Unnamed"),
            "url": config[section].get("PROVIDER_URL", "").rstrip("/")
        }

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Data consumer view</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f4f4f4;
        }
        h1 { color: #333; }
        .connector-list, .asset-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .card:hover { transform: scale(1.02); }
        .details {
            margin-top: 40px;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #007BFF;
            cursor: pointer;
        }
        .back-link:hover { text-decoration: underline; }
        .policy {
            font-size: 0.9em;
            color: #444;
            margin-top: 8px;
            white-space: pre-wrap;
        }
        button {
            margin-top: 10px;
            padding: 8px 16px;
            background: #007BFF;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover { background: #0056b3; }
        .negotiation {
            margin-top: 15px;
            padding: 10px;
            border-left: 4px solid #28a745;
            background: #f9fff9;
        }
    </style>
</head>
<body>
    <h1>Data consumer view</h1>

    {% if not selected and not assets %}
    <h2>Available connectors</h2>
    <div class="connector-list">
        {% for key, conn in connectors.items() %}
        <div class="card" onclick="window.location.href='/connector/{{ key }}'">
            <h3>{{ conn.name }}</h3>
            <p><small>{{ conn.url }}</small></p>
        </div>
        {% endfor %}
    </div>
    {% elif selected and assets %}
    <div class="details">
        <div class="back-link" onclick="window.location.href='/'">&larr; Back to connectors</div>
        <h2>{{ connector.name }}</h2>
        <p><strong>Provider URL:</strong> {{ connector.url }}</p>
        <h3>Available assets</h3>
        <div class="asset-list">
            {% for asset in assets %}
            <div class="card">
                <h4>{{ asset.name }}</h4>
                <p><b>ID:</b> {{ asset.id }}</p>
                <p><b>Description:</b> {{ asset.description }}</p>
                <p><b>Content type:</b> {{ asset.contenttype }}</p>
                <p><b>Policy:</b><br>{{ asset.policy | replace('\\n','<br>') | safe }}</p>

                <form method="post" action="/negotiate/{{ connector_id }}/{{ asset.id }}">
                    <button type="submit">Negotiate contract</button>
                </form>

                {% if negotiations and negotiations.get(asset.id) %}
                <div class="negotiation">
                    <b>Contract agreement details:</b><br>
                    <b>Contract negotiation ID:</b> {{ negotiations[asset.id].negotiation_id }}<br>
                    <b>State:</b> {{ negotiations[asset.id].state }}<br>
                    <b>Contract agreement ID:</b> {{ negotiations[asset.id].agreement_id }}<br>
                    <b>Asset ID:</b> {{ negotiations[asset.id].asset_id }}<br>
                    <b>Correlation ID:</b> {{ negotiations[asset.id].correlation_id }}
                </div>
                {% endif %}
            </div>
            {% endfor %}
        </div>
    </div>
    {% endif %}
</body>
</html>
"""

def format_policy(policy):
    if not policy or (not policy.get("odrl:permission") and not policy.get("odrl:prohibition") and not policy.get("odrl:obligation")):
        return "No policies defined"

    perm = policy.get("odrl:permission")
    texts = []
    if isinstance(perm, dict):
        perm = [perm]
    if isinstance(perm, list):
        for p in perm:
            action = ""
            if isinstance(p.get("odrl:action"), dict):
                action = p.get("odrl:action", {}).get("@id", "")
            elif isinstance(p.get("odrl:action"), str):
                action = p.get("odrl:action", "")
            if action.startswith("odrl:"):
                action = action.replace("odrl:", "")
            constraint = p.get("odrl:constraint", {})
            if isinstance(constraint, dict):
                left = constraint.get("odrl:leftOperand", {}).get("@id", "")
                op = constraint.get("odrl:operator", {}).get("@id", "")
                right = constraint.get("odrl:rightOperand", "")
                if isinstance(left, str) and ":" in left:
                    left = left.split(":", 1)[1]
                if op == "odrl:eq":
                    op = "equals"
                texts.append(f"Action: {action}\\nConstraint: {left} {op} {right}")
    return "\\n".join(texts) if texts else "Policy defined"

def parse_assets(catalog_json):
    assets = []
    datasets = catalog_json.get("dcat:dataset", [])
    if isinstance(datasets, dict):
        datasets = [datasets]
    for ds in datasets:
        assets.append({
            "id": ds.get("id", ""),
            "name": ds.get("name", ""),
            "description": ds.get("description", ""),
            "contenttype": ds.get("contenttype", ""),
            "policy": format_policy(ds.get("odrl:hasPolicy", {})),
            "raw": ds
        })
    return assets

def get_catalog(connector):
    headers = {"Content-Type": "application/json"}
    payload = {
        "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
        "counterPartyAddress": f"{connector['url']}/protocol",
        "protocol": "dataspace-protocol-http"
    }
    target_url = f"{CONSUMER_URL}/management/v3/catalog/request"
    resp = requests.post(target_url, headers=headers, data=json.dumps(payload))
    if resp.status_code == 200:
        return resp.json()
    else:
        raise Exception(f"Catalog request failed: {resp.text}")

@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE, connectors=connectors, selected=False, assets=None)

@app.route("/connector/<connector_id>")
def connector_detail(connector_id):
    connector = connectors.get(connector_id)
    if not connector:
        return "Connector not found", 404
    try:
        catalog = get_catalog(connector)
        assets = parse_assets(catalog)
    except Exception as e:
        return str(e), 500
    return render_template_string(
        HTML_TEMPLATE,
        connector=connector,
        connector_id=connector_id,
        selected=True,
        assets=assets,
        negotiations={}
    )

@app.route("/negotiate/<connector_id>/<asset_id>", methods=["POST"])
def negotiate(connector_id, asset_id):
    connector = connectors.get(connector_id)
    if not connector:
        return "Connector not found", 404
    try:
        # Re-query catalog
        catalog = get_catalog(connector)
        participant = catalog.get("dspace:participantId", "provider")
        datasets = catalog.get("dcat:dataset", [])
        if isinstance(datasets, dict):
            datasets = [datasets]
        dataset = next((ds for ds in datasets if ds.get("id") == asset_id), None)
        if not dataset:
            return "Asset not found in catalog", 404

        policy_block = dataset.get("odrl:hasPolicy", {})
        distribution = dataset.get("dcat:distribution", {})
        access_service = distribution.get("dcat:accessService", {})
        service_id = access_service.get("@id", "")

        # Build policy payload
        policy = {
            "@context": "http://www.w3.org/ns/odrl.jsonld",
            "@id": policy_block.get("@id", ""),
            "@type": "Offer",
            "assigner": participant,
            "target": service_id
        }

        perms = policy_block.get("odrl:permission", [])
        if perms:
            if isinstance(perms, dict):
                perms = [perms]
            policy["permission"] = []
            for p in perms:
                perm_obj = {"action": "use", "target": service_id}
                constraint = p.get("odrl:constraint", {})
                if constraint:
                    perm_obj["constraint"] = {
                        "@type": "AtomicConstraint",
                        "leftOperand": constraint.get("odrl:leftOperand", {}).get("@id", "location"),
                        "operator": constraint.get("odrl:operator", {}).get("@id", "eq"),
                        "rightOperand": constraint.get("odrl:rightOperand", "eu")
                    }
                policy["permission"].append(perm_obj)

        # Build negotiation payload
        negotiation_payload = {
            "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
            "@type": "ContractRequest",
            "counterPartyAddress": f"{connector['url']}/protocol",
            "protocol": "dataspace-protocol-http",
            "policy": policy
        }

        # Send negotiation request
        target_url = f"{CONSUMER_URL}/management/v3/contractnegotiations"
        resp = requests.post(target_url, headers={"Content-Type": "application/json"}, data=json.dumps(negotiation_payload))
        if resp.status_code != 200:
            return f"Negotiation request failed: {resp.text}", 500
        negotiation_id = resp.json().get("@id")

        # Poll for negotiation finalization
        detail_url = f"{CONSUMER_URL}/management/v3/contractnegotiations/{negotiation_id}"
        details = {}
        for _ in range(5):  # up to 5 retries
            resp2 = requests.get(detail_url, headers={"Content-Type": "application/json"})
            if resp2.status_code == 200:
                details = resp2.json()
                if details.get("state") == "FINALIZED":
                    break
            time.sleep(2)

        negotiation_result = {
            "negotiation_id": details.get("@id", ""),
            "state": details.get("state", ""),
            "agreement_id": details.get("contractAgreementId", ""),
            "asset_id": details.get("assetId", ""),
            "correlation_id": details.get("correlationId", "")
        }

        # Re-render connector page with negotiations
        catalog = get_catalog(connector)
        assets = parse_assets(catalog)
        negotiations = {asset_id: negotiation_result}

        return render_template_string(
            HTML_TEMPLATE,
            connector=connector,
            connector_id=connector_id,
            selected=True,
            assets=assets,
            negotiations=negotiations
        )

    except Exception as e:
        return f"Error during negotiation: {e}", 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8081)
