from flask import Flask, render_template_string, request, jsonify
import requests
import json
import os

app = Flask(__name__)

# --- Load configuration.properties ---
CONFIG = {}
if os.path.exists("configuration.properties"):
    with open("configuration.properties") as f:
        for line in f:
            if "=" in line:
                key, value = line.strip().split("=", 1)
                CONFIG[key.strip()] = value.strip()

PROVIDER_URL = CONFIG.get("PROVIDER_URL", "http://localhost:19193")
CONNECTOR_NAME = CONFIG.get("CONNECTOR_NAME", "Unnamed Connector")

POLICY_URL = f"{PROVIDER_URL}/management/v3/policydefinitions"
CONTRACT_URL = f"{PROVIDER_URL}/management/v3/contractdefinitions"
ASSET_URL = f"{PROVIDER_URL}/management/v3/assets"

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Data provider view</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f4f4f4;
        }
        h1, h2 {
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-width: 500px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin: 8px 0 16px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"], button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px 20px;
            border-radius: 4px;
        }
        input[type="submit"]:hover, button:hover {
            background-color: #0056b3;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0; top: 0;
            width: 100%; height: 100%;
            background-color: rgba(0,0,0,0.4);
        }
        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 400px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <h1>Data provider view</h1>
    <h2>{{ connector_name }}</h2>

    <form id="assetForm" method="post">
        <h3>Define new data product</h3>
        <label>ID:</label>
        <input type="text" name="id">
        <label>Name:</label>
        <input type="text" name="name">
        <label>Description:</label>
        <input type="text" name="description">


        <h4>Specify data source for the data product</h4>
        <label>Source Type:</label>
        <select name="source_type">
            <option value="HttpData">HttpData</option>
        </select>
        <label>Source Name:</label>
        <input type="text" name="source_name">
        <label>Base URL:</label>
        <input type="text" name="base_url">
        <label>Auth Key:</label>
        <input type="text" name="auth_key" value="X-API-Key">
        <label>Auth Code:</label>
        <input type="text" name="auth_code">

        <input type="submit" value="Create asset">
    </form>

    <!-- Contract Modal -->
    <div id="contractModal" class="modal">
      <div class="modal-content">
        <h2>Create contract</h2>
        <p>Define contract</p>
        <form id="contractForm">
            <label>Contract ID:</label>
            <input type="text" name="contract_id">

            <p>Selected asset</p>
            <input type="text" id="selectedAssetId" name="asset_id" readonly>

            <label>Policy:</label>
            <select name="policy_type">
                <option value="no_restrictions">Policy with no restrictions</option>
                <option value="eu_only">Only to be used within EU</option>
            </select>

            <button type="button" onclick="submitContract()">Create contract</button>
        </form>
      </div>
    </div>

    <script>
        const assetForm = document.getElementById("assetForm");
        const contractModal = document.getElementById("contractModal");
        const selectedAssetIdField = document.getElementById("selectedAssetId");

        assetForm.addEventListener("submit", function(event){
            event.preventDefault();
            fetch("/create_asset", {
                method: "POST",
                body: new FormData(assetForm)
            }).then(res => res.json())
              .then(data => {
                if (data.success) {
                    selectedAssetIdField.value = data.asset_id;
                    contractModal.style.display = "block";
                } else {
                    alert("Asset creation failed: " + data.error);
                }
            });
        });

        function submitContract(){
            fetch("/create_contract", {
                method: "POST",
                body: new FormData(document.getElementById("contractForm"))
            }).then(res => res.json())
              .then(data => {
                if (data.success) {
                    alert("Data asset and contract created successfully");
                    contractModal.style.display = "none";
                } else {
                    alert("Error: " + data.error);
                }
            });
        }
    </script>
</body>
</html>
"""

@app.route("/")
def provider():
    return render_template_string(HTML_TEMPLATE, connector_name=CONNECTOR_NAME)

@app.route("/create_asset", methods=["POST"])
def create_asset():
    data = request.form.to_dict()

    payload = {
        "@context": {
            "@vocab": "https://w3id.org/edc/v0.0.1/ns/"
        },
        "@id": data.get("id"),
        "properties": {
            "name": data.get("name"),
            "description": data.get("description"),
            "contenttype": "application/json"
        },
        "dataAddress": {
            "type": data.get("source_type"),
            "name": data.get("source_name"),
            "baseUrl": data.get("base_url"),
            "proxyPath": "true",
            "authKey": data.get("auth_key"),
            "authCode": data.get("auth_code")
        }
    }

    headers = {"Content-Type": "application/json"}
    try:
        response = requests.post(ASSET_URL, headers=headers, data=json.dumps(payload))
        if response.status_code == 200:
            return jsonify(success=True, asset_id=data.get("id"))
        else:
            return jsonify(success=False, error=response.text)
    except Exception as e:
        return jsonify(success=False, error=str(e))

@app.route("/create_contract", methods=["POST"])
def create_contract():
    data = request.form.to_dict()
    contract_id = data.get("contract_id")
    asset_id = data.get("asset_id")
    policy_type = data.get("policy_type")

    headers = {"Content-Type": "application/json"}

    if policy_type == "no_restrictions":
        policy_id = "simple-policy"
        policy_payload = {
            "@context": {
                "@vocab": "https://w3id.org/edc/v0.0.1/ns/",
                "odrl": "http://www.w3.org/ns/odrl/2/"
            },
            "@id": policy_id,
            "policy": {
                "@context": "http://www.w3.org/ns/odrl.jsonld",
                "@type": "Set",
                "permission": [],
                "prohibition": [],
                "obligation": []
            }
        }
    else:
        policy_id = "eu-policy"
        policy_payload = {
            "@context": {
                "@vocab": "https://w3id.org/edc/v0.0.1/ns/"
            },
            "@id": policy_id,
            "policy": {
                "@context": "http://www.w3.org/ns/odrl.jsonld",
                "@type": "Set",
                "permission": [
                    {
                        "action": "use",
                        "constraint": {
                            "@type": "AtomicConstraint",
                            "leftOperand": "location",
                            "operator": "eq",
                            "rightOperand": "eu"
                        }
                    }
                ],
                "prohibition": [],
                "obligation": []
            }
        }

    contract_payload = {
        "@context": {
            "@vocab": "https://w3id.org/edc/v0.0.1/ns/"
        },
        "@id": contract_id,
        "accessPolicyId": policy_id,
        "contractPolicyId": policy_id,
        "assetsSelector": [
            {
                "@type": "https://w3id.org/edc/v0.0.1/ns/CriterionDto",
                "operandLeft": "https://w3id.org/edc/v0.0.1/ns/id",
                "operator": "=",
                "operandRight": asset_id
            }
        ]
    }

    try:
        r1 = requests.post(POLICY_URL, headers=headers, data=json.dumps(policy_payload))
        r2 = requests.post(CONTRACT_URL, headers=headers, data=json.dumps(contract_payload))
        if r1.status_code == 200 and r2.status_code == 200:
            return jsonify(success=True)
        else:
            return jsonify(success=False, error=f"Policy: {r1.text}, Contract: {r2.text}")
    except Exception as e:
        return jsonify(success=False, error=str(e))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
