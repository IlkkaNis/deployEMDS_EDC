from flask import Flask, request, render_template_string, jsonify

app = Flask(__name__)

latest_data = None

VIEW_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Data Viewer</title>
    <meta http-equiv="refresh" content="5"> <!-- Auto-refresh every 5s -->
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f4f4f4; }
        h1 { color: #333; }
        pre { background: #fff; padding: 20px; border-radius: 10px; white-space: pre-wrap; word-wrap: break-word; }
        .empty { color: #777; font-style: italic; }
    </style>
</head>
<body>
    <h1>Latest Received Data</h1>
    {% if data %}
        <pre>{{ data | tojson(indent=2) }}</pre>
    {% else %}
        <p class="empty">No data received yet.</p>
    {% endif %}
</body>
</html>
"""

@app.route("/receive-data", methods=["POST"])
def receive_data():
    global latest_data
    latest_data = request.get_json(force=True, silent=True)
    if not latest_data:
        return jsonify({"status": "error", "message": "Invalid JSON"}), 400
    print("\n**** NEW DATA RECEIVED ****\n", latest_data)
    return jsonify({"status": "success", "message": "Data received"}), 200

@app.route("/view")
def view_data():
    return render_template_string(VIEW_TEMPLATE, data=latest_data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
