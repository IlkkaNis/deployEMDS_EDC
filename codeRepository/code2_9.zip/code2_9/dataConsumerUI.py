from flask import Flask, render_template_string, request, redirect, url_for
import configparser
import os
import requests
import json
import time

app = Flask(__name__)

# --- Load configuration ---
CONFIG_FILE = "consumer-configuration.properties"
connectors = {}
CONSUMER_URL = ""

if os.path.exists(CONFIG_FILE):
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE)

    if "DEFAULT" in config and "CONSUMER_URL" in config["DEFAULT"]:
        CONSUMER_URL = config["DEFAULT"]["CONSUMER_URL"].rstrip("/")

    for section in config.sections():
        connectors[section] = {
            "name": config[section].get("CONNECTOR_NAME", "Unnamed"),
            "url": config[section].get("PROVIDER_URL", "").rstrip("/")
        }

# Store negotiation results per connector+asset
negotiations_store = {}
# Store received data (not used anymore, but kept for minimal changes)
received_data = {}

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Data consumer view</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background-color: #f4f4f4; }
        h1 { color: #333; }
        .connector-list, .asset-list {
            display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 20px; margin-top: 20px;
        }
        .card { background: white; padding: 20px; border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1); transition: transform 0.2s; }
        .card:hover { transform: scale(1.02); }
        .details { margin-top: 40px; background: #fff; padding: 20px; border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .back-link { display: inline-block; margin-bottom: 20px; color: #007BFF; cursor: pointer; }
        .back-link:hover { text-decoration: underline; }
        .policy { font-size: 0.9em; color: #444; margin-top: 8px; white-space: pre-wrap; }
        button { margin-top: 10px; padding: 8px 16px; background: #007BFF;
            border: none; color: white; border-radius: 5px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .negotiation, .transfer { margin-top: 15px; padding: 10px;
            border-left: 4px solid #28a745; background: #f9fff9; }
        .transfer-options { margin-top: 10px; }
        input[type=text] { width: 100%; padding: 6px; margin-top: 6px; margin-bottom: 6px; }
        pre { background: #eee; padding: 10px; border-radius: 5px; }

        /* Modal styles */
        .modal {
            display: none; position: fixed; z-index: 1000; left: 0; top: 0;
            width: 100%; height: 100%; overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fff; margin: 15% auto; padding: 20px; border-radius: 10px;
            width: 80%; max-width: 400px; text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        .modal-content h3 { margin-bottom: 10px; }
        .close-btn {
            margin-top: 15px; padding: 8px 16px; background: #007BFF;
            border: none; color: white; border-radius: 5px; cursor: pointer;
        }
        .close-btn:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1>Data consumer view</h1>

    {% if not selected and not assets %}
    <h2>Available connectors</h2>
    <div class="connector-list">
        {% for key, conn in connectors.items() %}
        <div class="card" onclick="window.location.href='/connector/{{ key }}'">
            <h3>{{ conn.name }}</h3>
            <p><small>{{ conn.url }}</small></p>
        </div>
        {% endfor %}
    </div>

    {% elif selected and assets %}
    <div class="details">
        <div class="back-link" onclick="window.location.href='/'">&larr; Back to connectors</div>
        <h2>{{ connector.name }}</h2>
        <p><strong>Provider URL:</strong> {{ connector.url }}</p>
        <h3>Available assets</h3>
        <div class="asset-list">
            {% for asset in assets %}
            <div class="card">
                <h4>{{ asset.name }}</h4>
                <p><b>ID:</b> {{ asset.id }}</p>
                <p><b>Description:</b> {{ asset.description }}</p>
                <p><b>Content type:</b> {{ asset.contenttype }}</p>
                <p><b>Policy:</b><br>{{ asset.policy | replace('\\n','<br>') | safe }}</p>

                <!-- Negotiate -->
                <form method="post" action="/negotiate/{{ connector_id }}/{{ asset.id }}">
                    <button type="submit">Negotiate contract</button>
                </form>

                {% if negotiations and negotiations.get(asset.id) %}
                <div class="negotiation">
                    <b>Contract agreement details:</b><br>
                    <b>Contract negotiation ID:</b> {{ negotiations[asset.id].negotiation_id }}<br>
                    <b>State:</b> {{ negotiations[asset.id].state }}<br>
                    <b>Contract agreement ID:</b> {{ negotiations[asset.id].agreement_id }}<br>
                    <b>Asset ID:</b> {{ negotiations[asset.id].asset_id }}<br>
                    <b>Correlation ID:</b> {{ negotiations[asset.id].correlation_id }}
                </div>

                <!-- Transfer options only if FINALIZED -->
                {% if negotiations[asset.id].state == "FINALIZED" %}
                <div class="transfer">
                    <b>Specify data destination:</b><br>
                    <form onsubmit="startTransfer(event, '{{ connector_id }}', '{{ asset.id }}')">
                        <div class="transfer-options">
                            <input type="text" name="url" id="url-{{ asset.id }}" placeholder="http://130.188.160.106:8080/receive-data">
                        </div>
                        <button type="submit">Start transfer</button>
                    </form>
                </div>
                {% endif %}

                {% endif %}
            </div>
            {% endfor %}
        </div>
    </div>
    {% endif %}

    <!-- Modal -->
    <div id="transferModal" class="modal">
        <div class="modal-content">
            <h3>Transfer Status</h3>
            <p id="modalMessage"></p>
            <button class="close-btn" onclick="closeModal()">Close</button>
        </div>
    </div>

    <script>
    async function startTransfer(event, connectorId, assetId) {
        event.preventDefault(); // prevent normal submit
        const url = document.getElementById(`url-${assetId}`).value || "http://130.188.160.106:8080/receive-data";
        try {
            const response = await fetch(`/transfer/${connectorId}/${assetId}`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `url=${encodeURIComponent(url)}`
            });
            const text = await response.text();
            showModal(text);
        } catch (err) {
            showModal("Error starting transfer: " + err);
        }
    }

    function showModal(message) {
        document.getElementById("modalMessage").innerText = message;
        document.getElementById("transferModal").style.display = "block";
    }

    function closeModal() {
        document.getElementById("transferModal").style.display = "none";
    }

    // Close modal when clicking outside
    window.onclick = function(event) {
        const modal = document.getElementById("transferModal");
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    </script>
</body>
</html>
"""

# --- Utility functions ---
def format_policy(policy):
    if not policy or (not policy.get("odrl:permission") and not policy.get("odrl:prohibition") and not policy.get("odrl:obligation")):
        return "No policies defined"
    perm = policy.get("odrl:permission")
    texts = []
    if isinstance(perm, dict):
        perm = [perm]
    if isinstance(perm, list):
        for p in perm:
            action = ""
            if isinstance(p.get("odrl:action"), dict):
                action = p.get("odrl:action", {}).get("@id", "")
            elif isinstance(p.get("odrl:action"), str):
                action = p.get("odrl:action", "")
            if action.startswith("odrl:"):
                action = action.replace("odrl:", "")
            constraint = p.get("odrl:constraint", {})
            if isinstance(constraint, dict):
                left = constraint.get("odrl:leftOperand", {}).get("@id", "")
                op = constraint.get("odrl:operator", {}).get("@id", "")
                right = constraint.get("odrl:rightOperand", "")
                if isinstance(left, str) and ":" in left:
                    left = left.split(":", 1)[1]
                if op == "odrl:eq":
                    op = "equals"
                texts.append(f"Action: {action}\nConstraint: {left} {op} {right}")
    return "\n".join(texts) if texts else "Policy defined"

def parse_assets(catalog_json):
    assets = []
    datasets = catalog_json.get("dcat:dataset", [])
    if isinstance(datasets, dict):
        datasets = [datasets]
    for ds in datasets:
        assets.append({
            "id": ds.get("id", ""),
            "name": ds.get("name", ""),
            "description": ds.get("description", ""),
            "contenttype": ds.get("contenttype", ""),
            "policy": format_policy(ds.get("odrl:hasPolicy", {})),
            "raw": ds
        })
    return assets

def get_catalog(connector):
    headers = {"Content-Type": "application/json"}
    payload = {
        "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
        "counterPartyAddress": f"{connector['url']}/protocol",
        "protocol": "dataspace-protocol-http"
    }
    target_url = f"{CONSUMER_URL}/management/v3/catalog/request"
    resp = requests.post(target_url, headers=headers, data=json.dumps(payload))
    if resp.status_code == 200:
        return resp.json()
    else:
        raise Exception(f"Catalog request failed: {resp.text}")

# --- Flask routes ---
@app.route("/")
def index():
    return render_template_string(HTML_TEMPLATE, connectors=connectors, selected=False, assets=None)

@app.route("/connector/<connector_id>")
def connector_detail(connector_id):
    connector = connectors.get(connector_id)
    if not connector:
        return "Connector not found", 404
    try:
        catalog = get_catalog(connector)
        assets = parse_assets(catalog)
    except Exception as e:
        return str(e), 500
    return render_template_string(
        HTML_TEMPLATE,
        connector=connector,
        connector_id=connector_id,
        selected=True,
        assets=assets,
        negotiations={},
        received_data=received_data
    )

@app.route("/negotiate/<connector_id>/<asset_id>", methods=["POST"])
def negotiate(connector_id, asset_id):
    connector = connectors.get(connector_id)
    if not connector:
        return "Connector not found", 404
    try:
        catalog = get_catalog(connector)
        participant = catalog.get("dspace:participantId", "provider")
        datasets = catalog.get("dcat:dataset", [])
        if isinstance(datasets, dict):
            datasets = [datasets]
        dataset = next((ds for ds in datasets if ds.get("id") == asset_id), None)
        if not dataset:
            return "Asset not found in catalog", 404

        policy_block = dataset.get("odrl:hasPolicy", {})
        asset_id_value = dataset.get("id", "")

        policy = {
            "@context": "http://www.w3.org/ns/odrl.jsonld",
            "@id": policy_block.get("@id", ""),
            "@type": "Offer",
            "assigner": participant,
            "target": asset_id_value
        }

        perms = policy_block.get("odrl:permission", [])
        if perms:
            if isinstance(perms, dict):
                perms = [perms]
            policy["permission"] = []
            for p in perms:
                perm_obj = {"action": "use", "target": asset_id_value}
                constraint = p.get("odrl:constraint", {})
                if constraint:
                    left = constraint.get("odrl:leftOperand", {})
                    op = constraint.get("odrl:operator", {})
                    perm_obj["constraint"] = {
                        "@type": "AtomicConstraint",
                        "leftOperand": left.get("@id", "location").split(":")[-1],
                        "operator": op.get("@id", "eq").replace("odrl:", ""),
                        "rightOperand": constraint.get("odrl:rightOperand", "eu")
                    }
                policy["permission"].append(perm_obj)

        negotiation_payload = {
            "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
            "@type": "ContractRequest",
            "counterPartyAddress": f"{connector['url']}/protocol",
            "protocol": "dataspace-protocol-http",
            "policy": policy
        }

        target_url = f"{CONSUMER_URL}/management/v3/contractnegotiations"
        resp = requests.post(target_url, headers={"Content-Type": "application/json"}, data=json.dumps(negotiation_payload))
        if resp.status_code != 200:
            return f"Negotiation request failed: {resp.text}", 500
        negotiation_id = resp.json().get("@id")

        detail_url = f"{CONSUMER_URL}/management/v3/contractnegotiations/{negotiation_id}"
        details = {}
        for _ in range(10):  # retry until FINALIZED
            resp2 = requests.get(detail_url, headers={"Content-Type": "application/json"})
            if resp2.status_code == 200:
                details = resp2.json()
                if details.get("state") == "FINALIZED":
                    break
            time.sleep(2)

        negotiation_result = {
            "negotiation_id": details.get("@id", ""),
            "state": details.get("state", ""),
            "agreement_id": details.get("contractAgreementId", ""),
            "asset_id": details.get("assetId", ""),
            "correlation_id": details.get("correlationId", "")
        }

        # store negotiation result
        negotiations_store[(connector_id, asset_id)] = negotiation_result

        catalog = get_catalog(connector)
        assets = parse_assets(catalog)
        negotiations = {asset_id: negotiation_result}

        return render_template_string(
            HTML_TEMPLATE,
            connector=connector,
            connector_id=connector_id,
            selected=True,
            assets=assets,
            negotiations=negotiations,
            received_data=received_data
        )

    except Exception as e:
        return f"Error during negotiation: {e}", 500

@app.route("/transfer/<connector_id>/<asset_id>", methods=["POST"])
def transfer(connector_id, asset_id):
    connector = connectors.get(connector_id)
    if not connector:
        return "Connector not found", 404
    try:
        negotiation = negotiations_store.get((connector_id, asset_id))
        if not negotiation or not negotiation.get("agreement_id"):
            return "No finalized contract agreement found for this asset", 400

        agreement_id = negotiation.get("agreement_id")
        external_url = request.form.get("url", "").strip() or "http://130.188.160.106:8080/receive-data"

        transfer_payload = {
            "@context": {"@vocab": "https://w3id.org/edc/v0.0.1/ns/"},
            "@type": "TransferRequestDto",
            "connectorId": "provider",
            "counterPartyAddress": f"{connector['url']}/protocol",
            "contractId": agreement_id,
            "protocol": "dataspace-protocol-http",
            "transferType": "HttpData-PUSH",
            "dataDestination": {"type": "HttpData", "baseUrl": external_url}
        }

        target_url = f"{CONSUMER_URL}/management/v3/transferprocesses"
        resp = requests.post(target_url, headers={"Content-Type": "application/json"}, data=json.dumps(transfer_payload))
        if resp.status_code != 200:
            return f"Transfer request failed: {resp.text}", 500

        return f"Transfer process started. Destination: {external_url}", 200

    except Exception as e:
        return f"Error during transfer: {e}", 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8081)
